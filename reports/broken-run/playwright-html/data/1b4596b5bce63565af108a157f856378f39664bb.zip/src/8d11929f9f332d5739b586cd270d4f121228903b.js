// Generated from: tests/features/self-healing/brittle-calculator.feature
import { test } from "../../tests/steps/fixtures.ts";

test.describe('Legacy calculator flow (intentionally broken locators)', () => {

  test.beforeEach('Background', async ({ Given, page }, testInfo) => { if (testInfo.error) return;
    await Given('I open the calculator using the legacy page object', null, { page }); 
  });
  
  test('Typing the loan amount (positional XPath silently drives the slider)', { tag: ['@broken', '@self-healing'] }, async ({ When, Then, page }) => { 
    await When('I type 2500000 into the legacy amount field', null, { page }); 
    await Then('the legacy amount field should contain 2500000', null, { page }); 
  });

  test('Typing the interest rate (absolute XPath)', { tag: ['@broken', '@self-healing'] }, async ({ When, page }) => { 
    await When('I type 10 into the legacy interest rate field', null, { page }); 
  });

  test('Clicking Calculate (renamed CSS class)', { tag: ['@broken', '@self-healing'] }, async ({ When, page }) => { 
    await When('I click the legacy Calculate button', null, { page }); 
  });

  test('Reading the EMI result (stale generated id)', { tag: ['@broken', '@self-healing'] }, async ({ Then, page }) => { 
    await Then('the legacy EMI result should show a rupee amount', null, { page }); 
  });

  test('Reading total interest (nth-child chain)', { tag: ['@broken', '@self-healing'] }, async ({ Then, page }) => { 
    await Then('the legacy total interest result should show a rupee amount', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('tests/features/self-healing/brittle-calculator.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":14,"tags":["@broken","@self-healing"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I open the calculator using the legacy page object","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I type 2500000 into the legacy amount field","stepMatchArguments":[{"group":{"start":7,"value":"2500000"},"parameterTypeName":"int"}]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"Then the legacy amount field should contain 2500000","stepMatchArguments":[{"group":{"start":39,"value":"2500000"},"parameterTypeName":"int"}]}]},
  {"pwTestLine":15,"pickleLine":18,"tags":["@broken","@self-healing"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I open the calculator using the legacy page object","isBg":true,"stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"When I type 10 into the legacy interest rate field","stepMatchArguments":[{"group":{"start":7,"value":"10"},"parameterTypeName":"float"}]}]},
  {"pwTestLine":19,"pickleLine":21,"tags":["@broken","@self-healing"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I open the calculator using the legacy page object","isBg":true,"stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I click the legacy Calculate button","stepMatchArguments":[]}]},
  {"pwTestLine":23,"pickleLine":24,"tags":["@broken","@self-healing"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I open the calculator using the legacy page object","isBg":true,"stepMatchArguments":[]},{"pwStepLine":24,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then the legacy EMI result should show a rupee amount","stepMatchArguments":[]}]},
  {"pwTestLine":27,"pickleLine":27,"tags":["@broken","@self-healing"],"steps":[{"pwStepLine":7,"gherkinStepLine":9,"keywordType":"Context","textWithKeyword":"Given I open the calculator using the legacy page object","isBg":true,"stepMatchArguments":[]},{"pwStepLine":28,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then the legacy total interest result should show a rupee amount","stepMatchArguments":[]}]},
]; // bdd-data-end